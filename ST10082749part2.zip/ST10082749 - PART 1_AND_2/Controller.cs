﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Diagnostics.Eventing.Reader;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace ST10082749___PART_1_AND_2
{
    internal class Controller
    {
        public List<Recipe> recipes = new List<Recipe>();

        //this method clears the data of the recipes that the user inserted on the program 
        public void clearData(Recipe recipe)
        {
            recipe = new Recipe();
        }

        //the method recevies data of the recipes tha are being added. 
        public void addRecipe()

        {
            //Ingredient ingredientObj = new Ingredient();
            Recipe recipe = new Recipe();

            Console.WriteLine("----------");
            Console.WriteLine("Add Recipe");
            Console.Write("Enter Recipe Name: ");
            recipe.Name = Console.ReadLine();
            Console.WriteLine("Enter Number of Ingredients");
            var noIngredients = Console.ReadLine();
            int numb = int.Parse(noIngredients);
            //Ingredient[] ingredients = new Ingredient[numb];
            for (int i = 0; i < numb; i++)
            {

                Console.WriteLine("Enter Ingredient Name :");
                var name1 = Console.ReadLine();
                Console.WriteLine("Enter Ingredient Quantity :");
                var quantity = Console.ReadLine();
                Console.WriteLine("Enter Unit of Measure :");
                var measure = Console.ReadLine();
                Console.WriteLine("Calories  ");  
                var  calories = Console.ReadLine();
                Console.WriteLine(" Enter food group "); 
                var foodGroup = Console.ReadLine();
                Ingredient ingredient = new Ingredient();
                ingredient.Name = name1;
                ingredient.Quantity = double.Parse(quantity); 
                ingredient.Measurement = measure;
                ingredient.Calories =double.Parse(calories) ;
                ingredient.FoodGroup = foodGroup;

                //ingredients[i] = a;
                recipe.Ingredients.Add(ingredient); 
            }

            Console.WriteLine("How Many steps: ");
            var noSteps = int.Parse(Console.ReadLine());
           //int numb2 = int.Parse(noSteps);
            //string[] steps = new string[int.Parse(numSteps)];
            for (int i = 0; i < noSteps; i++)
            {
                Console.WriteLine($"Enter Step {i + 1} :");
                var stepDesc = Console.ReadLine();
                recipe.Steps.Add(stepDesc);  


                //steps[i] = stepsDesc;

            }

            recipes.Add(recipe);
            Console.WriteLine("Recipe added sucessfully");

        }
        // method that deletes the selected recepie. 
        public void deleteRecipe(Recipe recipe)
        {
            recipes.Remove(recipe);
            Console.WriteLine("Recipe Deleted sucessfully");

        }
        public void viewSinglerecipe ()
        {
            Console.WriteLine("recipes Names");
            while (true)
            {
             
               for (int i = 0; i < recipes.Count; i++)
                {
                var recipe = recipes[i];
                Console.WriteLine($"{i + 1}-{recipe.Name}");
                }

                Console.WriteLine();
                var Selection = Console.ReadLine();
                var n = int.Parse(Selection);
                recipes[n-1].fullRecipe();
            }
          
        }
        // method that shows recepies to be viewed 
        public void viewRecipes()
        {
            var recipelist = recipes.OrderBy(r => r.Name) ;
            foreach (var recipe in recipelist)
            {
                recipe.fullRecipe();
                Console.WriteLine(" ----------------------- ");


                Console.WriteLine("*----------------------------------*");
                Console.WriteLine("Recipe Name: " + recipe.Name);
                Console.WriteLine("Recipe Ingrediends: ");
                Console.WriteLine("Name  |Quantity  |Measurement  | Calorie | FoodGroup ");

                foreach (var ingredient in recipe.Ingredients)
                {
                    Console.WriteLine($" {ingredient.Name}      |{ingredient.Quantity}      |{ingredient.Measurement}   | {ingredient.Calories}  | {ingredient.FoodGroup} ");
                }
                
                Console.WriteLine("*----------------------------------*");
                Console.WriteLine("Recipe Steps: ");
                for (int i = 0; i < recipe.Steps.Count; i++)
                {
                    //var step = steps[i];

                    Console.WriteLine($"step {i + 1} - {recipe.Steps[i]} ");
                    Console.WriteLine($"{recipe.Steps[i]}");
                }

            }
        }

            public void start()
        {

            while (true)
            {              
                Console.WriteLine("1 - View all Recipes \n" +
                                    "2 - Add recipe     \n" +
                                    "3 - Delete recipe  \n" +
                                    "4 -Scale by 0.3    \n" +
                                    "5 -Scale by 2      \n" +
                                    "6 - Scale by 3     \n" +
                                    "7 - Scale reset    \n" +
                                    "8 - view single recipe \n" + 
                                    "9 - Exit \n ");

                var input = Console.ReadLine();
                switch (int.Parse(input))
                {
                    case 1:
                        viewRecipes();
                        break;
                    case 2:
                        addRecipe();
                        Console.WriteLine(" Recipe has been Captured ");

                        break;
                    case 3:
                        Console.WriteLine("which recipe will be deleted ?");
                        for (int i = 0; i < recipes.Count; i++)
                        {
                            var recipe = recipes[i];
                            Console.WriteLine($"{i} - {recipe.Name}");

                        }
                        var selection = Console.ReadLine();
                       
                            

                        
                        deleteRecipe(recipes[int.Parse(selection)]);
                        break;
                    case 4:
                        foreach (var recipe in recipes)
                        {
                            foreach (var ingredient in recipe.Ingredients)
                            {
                                ingredient.CurrentScale = 1;
                                ingredient.scale(0.5);
                            }
                        }
                        Console.WriteLine(" The Sclase has been adjusted for 0.5");
                        break;
                    case 5:
                        foreach (var recipe in recipes)
                        {
                            foreach (var ingredient in recipe.Ingredients)
                            {
                                ingredient.CurrentScale = 2;
                                ingredient.scale(2);
                            }
                        }
                        Console.WriteLine(" The Sclase has  been adjusted for 2");
                        break;
                    case 6:
                        foreach (var recipe in recipes)
                        {
                            foreach (var ingredient in recipe.Ingredients)
                            {
                                ingredient.CurrentScale = 3;
                                ingredient.scale(3);
                            }
                        }
                        Console.WriteLine(" The Sclase has been adjusted for 3");
                        break;
                    case 7:
                        foreach (var recipe in recipes)
                        {
                            foreach (var ingredient in recipe.Ingredients)
                            {
                                ingredient.scaleReset();
                            }
                        }
                        Console.WriteLine(" The Scale has been reseted ");
                        break;

                    case 8:
                        viewSinglerecipe();
                        break; 
                    case 9:
                        System.Environment.Exit(0);
                        break;

                }
            }
        }
    }
}
