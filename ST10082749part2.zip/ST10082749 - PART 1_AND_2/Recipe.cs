﻿using System;
using System.Collections.Generic;
using System.Collections;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Dynamic;
using System.Xml.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Runtime.CompilerServices;

namespace ST10082749___PART_1_AND_2
{
    class Recipe
    {
        public delegate double RecipeDelegate();
        private string name; 
        public string Name
        {   get { return name; }
            set { name = value; }  
        }   
            
        private int noIngredients;
        public int NoIngredients
        {
            get { return noIngredients; }
            set { noIngredients = value; }
        }


        private int tempQuantity;
        public int TempQuantity
        {
            get { return tempQuantity; }
            set { tempQuantity = value; }
        }

        /* private  Ingredient[] ingredients;
         public Ingredient[] Ingredients 
         {
             get { return ingredients; }
             set { ingredients = value; }
         }*/

        private List<Ingredient> ingredients;
        public List<Ingredient> Ingredients
        {
            get { return ingredients; }
            set { ingredients = value; }
        }


        private int numberSteps;
        public int Numbersteps
        {
            get { return numberSteps; }
            set { numberSteps = value; }
        }

        private List<string> steps;
        public List<string> Steps
        {
            get { return steps; }
            set { steps = value; }
        }

        public Recipe()
        {
            name = string.Empty;
            noIngredients = 0;
            tempQuantity = 0;
            numberSteps = 0;
            
            steps = new List<string>();
            ingredients = new List<Ingredient>();
        }

        public void fullRecipe()
        {
            Console.WriteLine("*----------------------------------*");
            Console.WriteLine("Recipe Name: " + this.name);
            Console.WriteLine("Recipe Ingrediends: ");
            Console.WriteLine("Name  |Quantity  |Measurement  ");
            foreach (var ingredient in this.ingredients)
            {
                Console.WriteLine($" {ingredient.Name}      |{ingredient.Quantity}      |{ingredient.Measurement}");
            }

            Console.WriteLine($"The Total Calorie is {totalCalories()}");
            RecipeDelegate calories = totalCalories;
            calories();
            Console.WriteLine("*----------------------------------*");
            Console.WriteLine("Recipe Steps: ");
            for (int i = 0; i < steps.Count; i++)
            {
                var step = steps[i];
                Console.WriteLine($"step {i + 1}  ");
                Console.WriteLine($"{step}");
            }

            
        }
        public double totalCalories()
        {
            var temp = 0.0; 
            for (int i = 0; i < Ingredients.Count; i++) 
            {
               var ingredient = Ingredients[i];
                temp += ingredient.Calories;
            }
           if (temp > 300.0) 
            {
                Console.WriteLine("Calories over 300 UNHEALTHY "); 
            }
           else
            {
                Console.WriteLine($"Total Calories is {temp}"); 
            }
           return temp;
        }



    }
}
