﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ST10082749___PART_1_AND_2
{
    internal class Ingredient
    {
        private string name;
        public string Name
        {
            get { return name; }
            set { name = value; }
        }
        private double quantity;
        public double Quantity
        {
            get { return quantity; }
            set { quantity = value; }
        }
        private string measurement;
        public string Measurement
        {
            get { return measurement; }
            set { measurement = value; }
        }
        private int currentScale;
        public int CurrentScale
        {
            get { return currentScale; }
            set { currentScale = value; }

        }
        private string foodGroup;
        public string FoodGroup
        {
            get { return foodGroup; }
            set { foodGroup = value; }
        }
        private double calories ;
        public double Calories
        {
            get { return calories; }
            set { calories  = value; }
        }

        public Ingredient()
        {

            name = string.Empty;
            quantity = 0;
            measurement = string.Empty;
            currentScale = 0;
            foodGroup = string.Empty;
            calories = 0.0; 

        }
      
        public void scale(double num)
        {
            Quantity = quantity * num;
        }

        public void scaleReset()
        {
            switch (currentScale)
            {
                case 1:
                    Quantity /= 0.5;
                    break;
                case 2:
                    Quantity /= 2;
                    break;
                case 3:
                    Quantity /= 3;
                    break;


            }

        }
    }
}
